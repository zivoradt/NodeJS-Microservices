
module.exports = {
    customer: require('./customer'),
    appEvents: require('./api-events')
    
}
