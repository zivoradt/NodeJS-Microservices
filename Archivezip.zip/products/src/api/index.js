
module.exports = {
    
    products: require('./products'),
    appEvent: require('./api-events')
    
}
